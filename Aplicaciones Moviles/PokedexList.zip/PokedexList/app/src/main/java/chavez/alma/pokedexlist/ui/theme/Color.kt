package chavez.alma.pokedexlist.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val Green = Color(0xFF81CA85)

val Gold0 = Color(0xFFFDD681)
val Gold1 = Color(0xFFFFCA28)
val Gold2 = Color(0xFFE3AB00)
val Gold3 = Color(0xFFB98D07)
val OffWhite = Color(0xFFFAFAFA)
val DarkGray = Color(0xFF1F1F1F)
//typeColors
val Electric = Color(0xFFFFEB3B)
val Grass = Color(0xFF43A047)
val Fire = Color(0xFFE74440)
val Water = Color(0xFF00ACC1)
val Normal = Color(0xFF5D5631)
val Bug = Color(0xFF7CB342)
val Poison = Color(0xFF8E24AA)
val Ground = Color(0xFF983D21)
val Rock = Color(0xFF424241)
val Flying = Color(0xFF71A9D7)
val Fight = Color(0xFFFB8C00)
val Psych = Color(0xFFE86D95)
val Ghost = Color(0xFF5E35B1)
val Dragon = Color(0xFF3949AB)
val Dark = Color(0xFF131310)
val Ice = Color(0xFF9FA8DA)
val Fairy = Color(0xFFEF9A9A)